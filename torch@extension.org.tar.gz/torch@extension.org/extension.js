import St from 'gi://St'
import Gio from 'gi://Gio'
import GObject from 'gi://GObject'
import GUdev from 'gi://GUdev'

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as QuickSettings from 'resource:///org/gnome/shell/ui/quickSettings.js';

const TorchIndicator = GObject.registerClass(
class TorchIndicator extends QuickSettings.SystemIndicator {
    _init() {
        super._init();

        // Create an icon for the indicator
        this._indicator = this._addIndicator();
        this._indicator.icon_name = 'selection-mode-symbolic';
    }
});

const TorchToggle = GObject.registerClass(
class TorchToggle extends QuickSettings.QuickToggle {
    _init(proxy) {
        super._init({
            title: _('Torch'),
            iconName: 'selection-mode-symbolic',
            toggleMode: true,
        });

        this._proxy = proxy;

        this.connect('clicked', ()=> {
            this._toggleTorch();
        });
    }

    _toggleTorch() {
        if(this.checked)
            this._setBrightness(firstDevice, maxBrightness);
        else
            this._setBrightness(firstDevice, 0);
    }

    _setBrightness(firstDevice, brightness) {

    }

    get maxBrighness() {

    }

});

export default class TorchExtension extends Extension {
    enable() {
        this._indicator = new TorchIndicator(this);
        this._indicator.quickSettingsItems.push(new TorchToggle(this));

        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator);
    }

    disable() {
        this._indicator.quickSettingsItems.forEach(item => item.destroy());
        this._indicator.destroy();
        this._indicator = null;
    }
}
