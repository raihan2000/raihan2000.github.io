#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libphonenumber::phonenumber-shared" for configuration ""
set_property(TARGET libphonenumber::phonenumber-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(libphonenumber::phonenumber-shared PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libphonenumber.so.8.13"
  IMPORTED_SONAME_NOCONFIG "libphonenumber.so.8"
  )

list(APPEND _cmake_import_check_targets libphonenumber::phonenumber-shared )
list(APPEND _cmake_import_check_files_for_libphonenumber::phonenumber-shared "${_IMPORT_PREFIX}/lib/libphonenumber.so.8.13" )

# Import target "libphonenumber::geocoding-shared" for configuration ""
set_property(TARGET libphonenumber::geocoding-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(libphonenumber::geocoding-shared PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libgeocoding.so.8.13"
  IMPORTED_SONAME_NOCONFIG "libgeocoding.so.8"
  )

list(APPEND _cmake_import_check_targets libphonenumber::geocoding-shared )
list(APPEND _cmake_import_check_files_for_libphonenumber::geocoding-shared "${_IMPORT_PREFIX}/lib/libgeocoding.so.8.13" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
