<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message id="nemo_contacts-la-placeholder_display_label">
        <location filename="../lib/seasidecache.cpp" line="1230"/>
        <source>(Unnamed)</source>
        <extracomment>The display label for a contact which has no name or nickname.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message id="nemo_contacts_name_structure_2_tokens">
        <location filename="../lib/seasidecache.cpp" line="1252"/>
        <source>FL</source>
        <extracomment>Format string for allocating 2 tokens to name parts - 2 characters from the set [FMLPS]</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message id="nemo_contacts_name_structure_3_tokens">
        <location filename="../lib/seasidecache.cpp" line="1256"/>
        <source>FML</source>
        <extracomment>Format string for allocating 3 tokens to name parts - 3 characters from the set [FMLPS]</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message id="nemo_contacts_name_structure_4_tokens">
        <location filename="../lib/seasidecache.cpp" line="1260"/>
        <source>FFML</source>
        <extracomment>Format string for allocating 4 tokens to name parts - 4 characters from the set [FMLPS]</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
