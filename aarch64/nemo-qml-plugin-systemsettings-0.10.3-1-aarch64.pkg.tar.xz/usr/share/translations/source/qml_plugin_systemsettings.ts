<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message id="systemsettings-la-region">
        <location filename="../src/languagemodel.cpp" line="218"/>
        <source>Region: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="systemsettings-li-device_owner">
        <location filename="../src/userinfo.cpp" line="296"/>
        <source>Device owner</source>
        <extracomment>Default value for device owner&apos;s name when it is not set</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message id="systemsettings-li-guest_user">
        <location filename="../src/userinfo.cpp" line="300"/>
        <source>Guest user</source>
        <extracomment>Default value for guest user&apos;s name when it is not set</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
