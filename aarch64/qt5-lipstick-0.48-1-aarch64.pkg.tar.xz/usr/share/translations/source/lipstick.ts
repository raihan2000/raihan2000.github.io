<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message id="qtn_ener_charging">
        <location filename="../../src/notifications/batterynotifier.cpp" line="419"/>
        <source>Charging</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_charcomp">
        <location filename="../../src/notifications/batterynotifier.cpp" line="424"/>
        <source>Charging complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_remcha">
        <location filename="../../src/notifications/batterynotifier.cpp" line="429"/>
        <source>Disconnect charger from power supply to save energy</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_repcharger">
        <location filename="../../src/notifications/batterynotifier.cpp" line="434"/>
        <source>Charging not started. Replace charger.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_rebatt">
        <location filename="../../src/notifications/batterynotifier.cpp" line="439"/>
        <source>Recharge battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_ent_psnote">
        <location filename="../../src/notifications/batterynotifier.cpp" line="444"/>
        <source>Entering power save mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_exit_psnote">
        <location filename="../../src/notifications/batterynotifier.cpp" line="449"/>
        <source>Exiting power save mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_lowbatt_with_percentage">
        <location filename="../../src/notifications/batterynotifier.cpp" line="455"/>
        <source>Low battery: %1%</source>
        <extracomment>Shown when the battery is low. %1 = current battery level as a percentage</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ener_nopowcharge">
        <location filename="../../src/notifications/batterynotifier.cpp" line="460"/>
        <source>Not enough power to charge</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_ap_lipstick">
        <location filename="../../src/notifications/notificationmanager.cpp" line="829"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_high_temp_warning">
        <location filename="../../src/notifications/thermalnotifier.cpp" line="35"/>
        <source>Device is getting hot. Close all apps.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_high_temp_alert">
        <location filename="../../src/notifications/thermalnotifier.cpp" line="39"/>
        <source>Device is overheating. turn it off.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_low_temp_warning">
        <location filename="../../src/notifications/thermalnotifier.cpp" line="43"/>
        <source>Low temperature warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_high_temp">
        <location filename="../../src/shutdownscreen.cpp" line="84"/>
        <source>Temperature too high. Device shutting down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_unplug_usb">
        <location filename="../../src/shutdownscreen.cpp" line="89"/>
        <source>USB cable plugged in. Unplug the USB cable to shutdown.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="qtn_shut_batt_empty">
        <location filename="../../src/shutdownscreen.cpp" line="94"/>
        <source>Battery empty. Device shutting down.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
